/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author admin
 */
@WebServlet(name = "SignUpOrg", urlPatterns = {"/SignUpOrg"})
public class SignUpOrg extends HttpServlet {

    private Connection conn;

    @Override
    public void init() {
        conn = (Connection) getServletContext().getAttribute("connection");
    }

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet SignUpOrg</title>");
            out.println("</head>");
            out.println("<body>");

            String Login_ID2 = "ORG";
            String username2 = request.getParameter("username2");
            String password2 = request.getParameter("password2");

            //String User_ID2 = "2";
            String fname2 = request.getParameter("fname2");
            String lname2 = request.getParameter("lname2");
            String email2 = request.getParameter("email2");

            String phone2 = request.getParameter("phone2");

            String com_ID2 = "";
            String comName2 = request.getParameter("comName2");
            String comPhone2 = request.getParameter("comPhone2");

            try {
                Statement stmt = conn.createStatement();

                //Login_ID1 
                String num = "Select count(Login_ID) from Account where Login_ID Like 'ORG%'";
                ResultSet num1 = stmt.executeQuery(num);
                num1.next();
                String numS = num1.getString("count(Login_ID)");
                for (int i = numS.length(); i < 3; i++) {
                    Login_ID2 += "0";
                }
                Login_ID2 += numS;

                //Com_ID2
                String check = "Select * from Organizer_company where Company_name = '" + comName2 + "' ";
                ResultSet rs = stmt.executeQuery(check);
                
                if (rs.next()) {
                    com_ID2 = rs.getString("Company_ID");
                    out.println(com_ID2);
                    String sql3 = "Insert into Contact_person values('" + Login_ID2 + "', '" + comPhone2 + "', '" + com_ID2 + "')";
                    int numRow3 = stmt.executeUpdate(sql3);                    
                }
                else {
                    String numCom = "Select count(Company_ID) from Organizer_company";
                    ResultSet numCom1 = stmt.executeQuery(numCom);
                    numCom1.next();
                    String comS = numCom1.getString("count(Company_ID)");
                    for (int i = numS.length(); i < 3; i++) {
                        com_ID2 += "0";
                    }
                    com_ID2 += comS;
                    String sql4 = "Insert into Organizer_company values('" + com_ID2 + "', '"
                            + comPhone2 + "', '" + comName2 + "')";
                    int numRow4 = stmt.executeUpdate(sql4);
                    
                    String sql3 = "Insert into Contact_person values('" + Login_ID2 + "', '" + comPhone2 + "', '" + com_ID2 + "')";
                    int numRow3 = stmt.executeUpdate(sql3); 
                    
                }

                //Insert Table
                String sql1 = "Insert into Account values('" + Login_ID2 + "', '"
                        + password2 + "', '" + username2 + "', '" + Login_ID2 + "')";
                int numRow1 = stmt.executeUpdate(sql1);

                String sql2 = "Insert into User values('" + Login_ID2 + "', '"
                        + fname2 + "', '" + email2 + "', '" + lname2 + "')";
                int numRow2 = stmt.executeUpdate(sql2);



                RequestDispatcher obj = request.getRequestDispatcher("What.html");
                if (numRow1 == 1) {
                    obj.forward(request, response);
                }
                /*if (numRow2 == 1) {
                    obj.forward(request, response);
                }
                if (numRow3 == 1) {
                    obj.forward(request, response);
                }
                /*if (numRow4 == 1) {
                    obj.forward(request, response);
                }*/

            } catch (SQLException ex) {
                Logger.getLogger(SignUpOrg.class.getName()).log(Level.SEVERE, null, ex);
            }

            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
